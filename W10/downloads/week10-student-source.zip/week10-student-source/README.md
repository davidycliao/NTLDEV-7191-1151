# Week 10 student materials and editable slides

Start with [Week 10 materials](W10/README.md).

## View the materials

- Open [the slides](W10/slide/week10.html) in your browser, or read the [PDF](W10/slide/week10.pdf). These supplied files can be viewed offline.
- Use the left and right arrow keys to follow the slide focus boxes.
- Open the [Lab guide](W10/lab/Lab_Session_W10.html) and follow the [Lab instructions](W10/lab/README.md). The two notebooks, required saved dataset and referenced output records are included directly in `W10/lab/`.

## Edit and render the slides

Install Quarto if needed. Open a terminal in this extracted folder and run:

```bash
quarto render W10/slide/week10.qmd
```

Edit `W10/slide/week10.qmd` and render again to update `W10/slide/week10.html`. Keep the included `W10/assets/` files in their existing relative locations. The source sets `execute: eval: false`, so rendering the presentation displays the code without training models.

The Lab guide contains corrected working code. The supplied 2024 notebooks retain their original cells and saved outputs; use a working copy for your own run. Keep new training results separate from the dated preparation checks and original model records.
