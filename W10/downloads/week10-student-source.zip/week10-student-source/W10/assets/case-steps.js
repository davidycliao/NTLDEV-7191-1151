/* Case reading cues. Fragment notes use Reveal's native speaker-notes channel. */
(function () {
  'use strict';

  const cueSelector = '.fragment.case-cue';
  const escapeHTML = value => value.replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
  let initialized = false;
  let printing = /(?:\?|&)print-pdf(?:[=&]|$)/.test(window.location.search);

  function cuesFor(slide) {
    return Array.from(slide.querySelectorAll(cueSelector)).sort((a, b) =>
      Number(a.dataset.fragmentIndex) - Number(b.dataset.fragmentIndex));
  }

  function prepareNotes(slide, cues) {
    // Student files have no notes; no narration is inserted into those files.
    const notes = Array.from(slide.querySelectorAll('aside.notes'))
      .find(aside => !aside.closest('.fragment'));
    if (!notes) return;
    const paragraphs = Array.from(notes.children).filter(child => child.tagName === 'P');
    cues.forEach((cue, index) => {
      const indices = (cue.dataset.noteIndices || '')
        .split(',').filter(value => value.trim() !== '').map(Number);
      const selected = indices.map(position => paragraphs[position]).filter(Boolean);
      const label = escapeHTML(cue.dataset.stepLabel || '');
      const heading = slide.classList.contains('english-notes')
        ? `<p><strong>Step ${index + 1}/${cues.length} | ${label}</strong></p>`
        : `<p><strong>第 ${index + 1}/${cues.length} 步｜${label}</strong></p>`;
      cue.setAttribute('data-notes', heading + selected.map(p => p.outerHTML).join(''));
    });
  }

  function clearFocus() {
    document.querySelectorAll('.case-active').forEach(target => target.classList.remove('case-active'));
  }

  function update() {
    clearFocus();
    if (printing) return;
    const slide = window.Reveal.getCurrentSlide();
    if (!slide) return;
    const cues = cuesFor(slide);
    if (!cues.length) return;
    const current = slide.querySelector('.current-fragment.case-cue');
    const status = slide.querySelector('.case-step-status');
    if (status) {
      status.setAttribute('aria-live', 'polite');
      status.textContent = current
        ? `${cues.indexOf(current) + 1} / ${cues.length} · ${current.dataset.stepLabel || ''}`
        : `← / →  Follow the ${slide.classList.contains('lab-code-guided') ? 'code' : 'case'}`;
    }
    if (!current) return;
    let selectors;
    try { selectors = JSON.parse(current.dataset.focusTargets || '[]'); }
    catch (_) { return; }
    if (!Array.isArray(selectors)) return;
    selectors.forEach(selector => {
      try {
        slide.querySelectorAll(selector).forEach(target => target.classList.add('case-active'));
      } catch (_) { /* Keep the presentation navigable if a future selector is invalid. */ }
    });
  }

  function initialize() {
    if (initialized || !window.Reveal) return;
    initialized = true;
    document.querySelectorAll('.reveal .slides section').forEach(slide => {
      const cues = cuesFor(slide);
      if (cues.length) prepareNotes(slide, cues);
    });
    ['ready', 'slidechanged', 'fragmentshown', 'fragmenthidden'].forEach(event =>
      window.Reveal.on(event, update));
    if (window.Reveal.isReady()) update();
  }

  window.addEventListener('beforeprint', () => { printing = true; clearFocus(); });
  window.addEventListener('afterprint', () => {
    printing = /(?:\?|&)print-pdf(?:[=&]|$)/.test(window.location.search);
    if (initialized) update();
  });
  if (window.Reveal) initialize();
  else document.addEventListener('DOMContentLoaded', initialize, {once: true});
  window.addEventListener('load', initialize, {once: true});
})();
