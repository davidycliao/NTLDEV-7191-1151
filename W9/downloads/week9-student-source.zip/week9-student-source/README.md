# W9 editable student slides

This package contains the student materials for Word Embeddings and Political Language.
Open `W9/lab/Lab_Session_W9.html` in a browser for the classroom Lab. We begin with
Flair and the original word-vector/PCA exercise, then use conText to compare
individual uses of immigration. The prepared results can be read without fitting
models. To run the examples, prepare the R/Python packages and model cache as
described in the handout before class.

The Lab uses Code and Output tabs on the same slide. The class retains four cases,
110 minutes overall and a 30-minute Lab. Supplementary slides and after-class
exercises follow the classroom sequence.

Presenter Notes, instructor scripts, teacher solutions and full research-paper
PDFs are not included. Some reading links open the public course website.

## Edit and preview

Open `W9/slide/week9.html` or `W9/slide/week9.pdf` for the supplied slides.
Edit `W9/slide/week9.qmd`. With Quarto installed, from this extracted directory run:

    quarto render W9/slide/week9.qmd

For a browser preview with the included relative Lab links:

    quarto preview W9/slide/week9.qmd

The supplied source is the complete student deck. It does not require the private
lecture build scripts or source sections. The shared W8 theme is included solely
to keep its relative CSS path working.
