# Student lecture source

This bundle contains the Week 2 lecture, Text Preparation in R and Python: Collaborative Workflow.
The source filename is `slide/week1.qmd`. It contains 64 slides without presenter notes.

## Render the slides

1. Extract the whole ZIP and keep the `slide/` and `image/` folders together.
2. Install R and Quarto if needed, then install the R packages once:

   ```r
   install.packages(c("quanteda", "stringr", "knitr"))
   ```

3. Open `slide/week1.qmd` in RStudio or Positron and click Render. Alternatively, from the `slide` folder run:

   ```sh
   quarto render week1.qmd --to revealjs
   ```

4. Open the generated `week1.html` in a browser.

The examples used during rendering are embedded in the QMD. No UDPipe models, Python packages, API calls, or lab datasets are needed to render these slides. Code displayed as plain R or Python examples is illustrative and is not run during rendering.

The lab referred to in the slides is a separate download from the course repository. This bundle contains the lecture source, styles, and images.
