# Student lecture source

This bundle contains the Week 2 lecture, Text Preparation in R and Python: Collaborative Workflow.
The source filename is `W2/slide/week2.qmd`. It contains 64 slides without presenter notes.

## Render the slides

1. Extract the whole ZIP and keep the `W2/`, `styles/`, and `image/` folders together.
2. Install R and Quarto if needed, then install the R packages once:

   ```r
   install.packages(c("quanteda", "stringr", "knitr"))
   ```

3. Open `W2/slide/week2.qmd` in RStudio or Positron and click Render. Alternatively, from the extracted `week2-student-source` folder run:

   ```sh
   quarto render W2/slide/week2.qmd --to revealjs
   ```

4. Open the generated `W2/slide/week2.html` in a browser.

The source uses `../../styles/` and `../../image/`, preserving the course repository's shared-asset layout. Keep these relative paths and folders intact when editing the slides.

The examples used during rendering are embedded in the QMD. No UDPipe models, Python packages, API calls, or lab datasets are needed to render these slides. Code displayed as plain R or Python examples is illustrative and is not run during rendering.

The lab referred to in the slides is a separate download from the course repository. This bundle contains the lecture source, styles, and required images. Presenter files, speaker notes, full papers, and custom PDF-rendering assets are excluded.
