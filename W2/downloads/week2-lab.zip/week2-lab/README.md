# Week 2 lab

Extract the entire ZIP, then open [the instructions](W2/lab/README.md).
Read `W2/lab/Lab_Session_W2.html` and run `W2/lab/Lab_Session_W2.R`
one section at a time. The setup finds the included data or asks you to select it.

Worked answers are in `W2/lab/answers/`; editable QMD files are in `W2/lab/source/`.
Figures are embedded in the HTML. Keep the `Data/` folder in place.

The lab is ungraded self-study practice with 11 exercises. Try them before
consulting the answers. Source attribution is included in the handout and lab README.
