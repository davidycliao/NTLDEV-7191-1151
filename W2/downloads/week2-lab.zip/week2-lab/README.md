# Week 2 lab

**National Taiwan University**  
**Text as Data: Computational Methods for Social Science Research**

This ZIP contains the complete Week 2 lab: instructions, R scripts, Quarto
handouts, rendered handouts, answer keys, data, and figures. The exercises are
ungraded self-study practice; no submission is required.

1. Extract the whole ZIP and keep its folders together.
2. Open [the lab instructions](W2/lab/README.md) and install the listed R packages.
3. Set the R working directory to the extracted `W2/lab` folder.
4. Open `Lab_Session_W2.R` or `Lab_Session_W2.qmd` in RStudio or Positron and run
   the examples section by section. Both formats use the included `Data/` folder.

Attempt the exercises before consulting the included answer keys.

## Acknowledgments

The design of this course draws primarily on Stefan Müller's quantitative text
analysis syllabus ([@stefan-mueller](https://github.com/stefan-mueller)). The lab
exercises and teaching materials are adapted from those developed by Martijn
Schoonvelde ([@hjmschoonvelde](https://github.com/hjmschoonvelde)) for the 2026
Essex Summer School course “Introduction to QTA.”

See the [course repository](https://github.com/davidycliao/NTLDEV-7191-1151)
for the syllabus and lecture materials.
