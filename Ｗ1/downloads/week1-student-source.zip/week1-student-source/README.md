# Student lecture source

This bundle contains the Week 1 lecture, How We Can Use Text as Data for Social Science Research.
The source filename is `Ｗ1/slide/week1.qmd`. It contains 38 slides without presenter notes.

## Render the slides

1. Extract the whole ZIP and keep the `Ｗ1/`, `styles/`, and `image/` folders together. The folder name `Ｗ1` uses a full-width W; keep its name unchanged.
2. Install R and Quarto if needed, then install the R packages once:

   ```r
   install.packages(c("knitr", "rmarkdown", "ggplot2", "dplyr"))
   ```

   The lecture setup loads `knitr`, `ggplot2`, and `dplyr`. Quarto's R rendering engine also uses `rmarkdown`.

3. Open `Ｗ1/slide/week1.qmd` in RStudio or Positron and click Render. Alternatively, from the extracted `week1-student-source` folder run:

   ```sh
   quarto render "Ｗ1/slide/week1.qmd" --to revealjs
   ```

4. Open the generated `Ｗ1/slide/week1.html` in a browser.

The source uses `../../styles/` and `../../image/`, preserving the course repository's shared-asset layout. Keep these relative paths and folders intact when editing the slides. The included `styles/slide-fit.html` adjusts slide content to fit the layout.

All local images needed for rendering are included. No Python packages, lab datasets, language models, or API calls are needed to render these slides. An R project is optional.

This bundle contains the lecture source, styles, layout helper, and required images. Presenter files, speaker notes, the retained Rmd source, full papers, and custom rendering scripts are excluded.
