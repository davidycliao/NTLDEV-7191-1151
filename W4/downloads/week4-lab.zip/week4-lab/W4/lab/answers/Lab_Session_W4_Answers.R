#' ---
#' title: "W4 Lab: Worked Answers"
#' subtitle: "LIWC-format dictionaries, custom policy rules, and a W6 preview"
#' format:
#'   html:
#'     embed-resources: true
#'     toc: true
#' execute:
#'   warning: false
#'   message: false
#' ---
#' 
#' Let's work through the results from our lab. For the validation exercise, we'll use the 24 example sentences and their supplied labels. Compare these outputs with your own, and read the sentences behind any differences. [Return to the student handout](../Lab_Session_W4.html).
#' 
## -----------------------------------------------------------------------------
# install.packages("quanteda")  # run once before class
library(quanteda)
# Find the lab folder; if asked, select workflow.R inside W4/lab.
paths <- c("W4/lab/workflow.R", "lab/workflow.R",
           "../lab/workflow.R", "../workflow.R", "workflow.R")
found <- paths[file.exists(paths)]
if (length(found) == 0) found <- file.choose()
setwd(dirname(normalizePath(found[1])))
source("workflow.R")  # load the data and prepared examples

#' 
#' Run the setup block once, then follow sections 1–4 in order. If a file picker opens, choose `workflow.R` inside the extracted lab. The party comparison is optional.
#' 
#' ## 1. LIWC format and sentiment
#' 
## -----------------------------------------------------------------------------
toy_sentiment
texts <- c("The policy is good.", "The policy is not good.")
example_tokens <- tokens(texts, remove_punct = TRUE)
example_dfm <- dfm(example_tokens)
example_hits <- dfm_lookup(example_dfm, toy_sentiment)
counts <- convert(example_hits, to = "data.frame")
counts
word_count <- ntoken(example_tokens)
positive <- counts$positive
negative <- counts$negative
100 * (positive - negative) / word_count
# The setup above created these five named examples.
check_texts
check_tokens <- tokens(check_texts, remove_punct = TRUE)
check_dfm <- dfm(check_tokens)
check_hits <- dfm_lookup(check_dfm, toy_sentiment)
convert(check_hits, to = "data.frame")

# Prepared by workflow.R using the three formulas explained in class.
check_scores

# TRUE counts as 1; the mean is the fraction without a match.
mean(sentiment$no_match)

#' 
#' Category 1 is `positive`; category 2 is `negative`. The dictionary matches words without interpreting who or what is being evaluated. The prepared `check_scores` table uses the original dictionary; changing a dictionary requires rerunning the scoring code.
#' 
#' We get 25 net matches per 100 tokens for `good` and 20 for `not good`. Our rule counts `good` as positive in both sentences; adding `not` increases the denominator. An unmatched text has zero coverage. A text with balanced positive and negative counts has zero net tone but nonzero coverage. An empty text has a zero denominator, so its rates are missing. When we apply the dictionary to the speeches, a text with no matches may still express an opinion in words our list does not include.
#' 
#' Our ten-word teaching dictionary uses LIWC's `.dic` file format. We apply it with quanteda and calculate our own score, so the result differs from LIWC's Tone measure. See [LIWC Analysis](https://liwc.app/help/liwc) and [quanteda import documentation](https://quanteda.io/reference/dictionary.html).
#' 
#' ## 2. Build an energy-policy dictionary
#' 
## -----------------------------------------------------------------------------
policy_entries <- read.csv("Dictionaries/energy_policy.csv")
v1_entries <- subset(policy_entries, version == "v1")
energy_v1 <- dictionary(list(energy = v1_entries$pattern))
v2_entries <- subset(policy_entries, version == "v2")
energy_v2 <- dictionary(list(energy = v2_entries$pattern))
contexts <- kwic(discovery_tokens, pattern = c("power", "gas", "bill*"),
                 valuetype = "glob", window = 8)
head(contexts, 8)
example_context <- kwic(discovery_tokens, pattern = "bill*", window = 8)
# The supplied corpus contains matches to bill*.
first_id <- example_context$docname[1]
original <- subset(speeches, doc_id == first_id)
original$text


#' 
#' In these contexts, `power` may refer to political authority, `bill*` may match legislation, and `gas` may refer to tear gas. We need to read the passage to decide whether each match concerns energy. If we propose another version, we should be able to point to development examples that explain each change.
#' 
#' ### Change one rule, then rerun
#' 
#' V1 includes `power`, which can mean political authority. Replace it with `wind farm*`, then compare the old and revised dictionaries on two teaching sentences:
#' 
## -----------------------------------------------------------------------------
energy_revised <- dictionary(list(
  energy = c("energy", "wind farm*", "electric*", "gas", "bill*")
))
revision_texts <- c(
  wind = "The government should approve new wind farms.",
  authority = "Parliament must retain the power to question ministers."
)
revision_tokens <- tokens(revision_texts, remove_punct = FALSE)

before_tokens <- tokens_lookup(revision_tokens, energy_v1, capkeys = FALSE)
before_counts <- convert(dfm(before_tokens), to = "data.frame")
after_tokens <- tokens_lookup(revision_tokens, energy_revised, capkeys = FALSE)
after_counts <- convert(dfm(after_tokens), to = "data.frame")

data.frame(sentence = before_counts$doc_id,
           before = before_counts$energy,
           after = after_counts$energy)

#' 
#' **Read the result:** `wind` changes from 0 to 1; `authority` changes from 1 to 0. Our change fixes both examples. Next, we'll check other sentences to see which mistakes remain.
#' 
#' Your own revision may differ from this example. To explain it, show the entry you changed, a passage that supports the change, and a case it might still get wrong. We can use `kwic(discovery_tokens, phrase("wind farm*"))` as a starting point for checking a phrase in the speeches.
#' 
#' For sections 3–4, we'll use the supplied **`energy_v2`** so we can compare our results. Your own changes remain in `energy_revised`; the scores below refer to `energy_v2`.
#' 
#' ## 3. Development errors
#' 
## -----------------------------------------------------------------------------
# Read the labelled teaching examples and generate predictions explicitly.
synthetic <- read.csv("Data/synthetic_validation.csv")
example_corpus <- corpus(synthetic, text_field = "text", docid_field = "doc_id")
example_tokens <- tokens(example_corpus, remove_punct = FALSE)

# Apply v1, then v2. Each matched phrase counts once.
v1_matches <- tokens_lookup(example_tokens, energy_v1, capkeys = FALSE)
v1_dfm <- dfm(v1_matches)
v1_binary <- dfm_weight(v1_dfm, scheme = "boolean")
v1_predictions <- convert(v1_binary, to = "data.frame")
synthetic$v1 <- v1_predictions$energy

v2_matches <- tokens_lookup(example_tokens, energy_v2, capkeys = FALSE)
v2_dfm <- dfm(v2_matches)
v2_binary <- dfm_weight(v2_dfm, scheme = "boolean")
v2_predictions <- convert(v2_binary, to = "data.frame")
synthetic$v2 <- v2_predictions$energy

dev <- subset(synthetic, split == "development")
errors <- subset(dev, v1 != human)
errors[, c("doc_id", "text", "human", "v1", "v2")]

#' 
#' The development examples show why we might remove standalone `power`, `gas` and `bill*`, and add expressions about renewable energy, solar panels, wind farms and fossil fuels. V2 fixes several mistakes, but it still matches `energy` when the sentence describes a person's enthusiasm. To address that case, we would need a rule that uses the surrounding words, then more examples to check whether it works.
#' 
#' ## 4. Synthetic test results
#' 
## -----------------------------------------------------------------------------
test <- subset(synthetic, split == "test")
# 0 = not relevant; 1 = relevant. Keep both categories in the table.
predicted <- factor(test$v2, levels = c(0, 1))
human <- factor(test$human, levels = c(0, 1))
table(predicted, human)
errors <- subset(test, v2 != human)
errors[, c("doc_id", "text", "human", "v2")]

#' 
#' Calculate the counts and fractions explicitly:
#' 
## -----------------------------------------------------------------------------
predicted <- test$v2
human <- test$human
TP <- sum(predicted == 1 & human == 1)
FP <- sum(predicted == 1 & human == 0)
FN <- sum(predicted == 0 & human == 1)
TN <- sum(predicted == 0 & human == 0)
precision <- TP / (TP + FP)
recall <- TP / (TP + FN)
F1 <- 2 * TP / (2 * TP + FP + FN)
c(TP = TP, FP = FP, FN = FN, TN = TN)
c(precision = precision, recall = recall, F1 = F1)

#' 
#' These denominators are nonzero. In other data, report an undefined rate as `NA` when its denominator is zero.
#' 
#' For v2, we get **TP = 4, FP = 1, FN = 2, TN = 5**. Precision = **0.80**, recall = **0.667**, F1 = **0.727**. V1 finds the same four relevant sentences but also flags four irrelevant ones. V2 reduces those false positives to one: figurative `energy`. It still misses the sentences about coal-mine closures and heating tariffs.
#' 
#' These results describe the **12 test sentences**. To evaluate our dictionary on parliamentary speeches, we would need human labels for those speeches.
#' 
#' If we read only the matches, we would never find the two missed sentences and could not calculate recall. When relevant texts are rare, predicting 0 for every text can give high accuracy while finding none of them. F1 helps us focus on precision and recall, but we should also report the four counts and explain how we chose the texts. Without predicted positives, precision is undefined; without relevant texts in our labeled sample, recall is undefined.
#' 
#' We could now add `coal` or `heating`, but that would use information from the test sentences to change our dictionary. We would need a fresh test set to evaluate that new version.
#' 
#' ## W6 preview: labels before models
#' 
#' W5 (October 9) is a holiday. W6 (October 16), **Human Coding and Document Classification**, covers annotation quality, inter-coder reliability, training/test sets and performance; its lab introduces Naive Bayes, SVM and cross-validation.
#' 
#' For the five-speech warm-up, explain how you reached each label. Point to a passage, apply our inclusion/exclusion rules, and note anything you are unsure about. We'll compare difficult cases and refine the labeling rules in W6. No model training or extra submission is required now.
#' 
#' We'll use these five speeches for discussion. We'll need more labeled texts for training and evaluation, with a separate test set that we leave aside while developing the model. Make your own reading-based judgments before looking at dictionary predictions.
#' 
#' ## Real-text validation in W6
#' 
#' Use the [three labeling rules in the handout](../Lab_Session_W4.html#energy-label-rules) for the five-speech preview. We'll work through independent coding and evaluation in W6. The parliamentary speeches have no supplied human labels; we'll need to collect those judgments before we can check the dictionary's performance on them.
#' 
#' ## Optional: compare parties
#' 
## -----------------------------------------------------------------------------
# quanteda adds counts within each party.
party_matches <- tokens_lookup(policy_tokens, energy_v2, capkeys = FALSE)
party_dfm <- dfm(party_matches)
party_dfm <- dfm_group(party_dfm, groups = party)

# Group original word counts separately to preserve the denominator.
party_words <- dfm(toks)
party_words <- dfm_group(party_words, groups = party)

party_summary <- convert(party_dfm, to = "data.frame")
party_summary$tokens <- ntoken(party_words)
party_summary$per1000 <- 1000 * party_summary$energy / party_summary$tokens
head(party_summary, 6)


#' 
#' We use `dfm_group()` to add counts within each party, `ntoken()` to count the original words, and `convert()` to display the result as a table. For each party, we divide total matches by total original word counts and multiply by 1,000. This lets us compare speeches of different total lengths. To interpret party differences, we still need to check the dates, topics and dictionary matches; the rate alone does not tell us whether a party supports a policy.
#' 
#' ## R session information
#' 
## -----------------------------------------------------------------------------
sessionInfo()

