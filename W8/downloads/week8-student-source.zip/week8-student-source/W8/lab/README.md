# Week 8 student lab

Keep the supplied W8 folder intact. Open W8/lab/Lab_Session_W8.html offline in a browser.

## Two complete analyses in R

Open W8/W8_lab.Rproj in RStudio, then classroom/W8.R. Install the eight listed packages before class. Restart R and run one small step at a time with Ctrl+Enter / Cmd+Enter, keeping the same R session.

1. **LDA:** read the supplied 719 complete speeches, clean the words, build one document-feature matrix, fit six topics, read complete mixtures and check provisional labels against original speeches.
2. **STM:** add party and election-period information to the same texts, fit the model, compare raw means with conditional differences, draw intervals and write a supported conclusion.

The primary script performs the analysis from the supplied raw speech sample through model estimation. Prepared alternative fits support the optional K check. The R packages are quanteda, quanteda.textstats, seededlda, stm, dplyr, tidyr, ggplot2 and jsonlite; seededlda supplies the ordinary LDA estimator here.

## Classroom route

Complete R00 before class. Follow R01, R02, R03a–R03b and E02, then R05a–R05e and E05. The 37-minute route allows 17 minutes for preparation/LDA/text reading, 15 for STM and 5 for interpretation. Complete E01, E03 and the optional R03c–R04c diagnostics after class. The full lab has 19 steps and five exercises. In the slides, each step has Code/Output tabs; Next switches to Output on the same slide.

At the end, report a provisional topic label with a quotation and possible counterexample. For STM, report the direction and size in percentage points, the covariates, uncertainty and the limits of an observational comparison.

Editable handouts are under lab/source. Rendering the QMD displays the captured R outputs; it does not estimate models. Original speeches can contain encoding artefacts. The source IDs and complete texts remain available for interpretation.
